export function formatVnd(value) {
  if (value == null || value === '') return '-';
  const num = typeof value === 'number'
    ? value
    : Number(String(value).replace(/[^\d-]/g, ''));
  if (Number.isNaN(num)) return '-';
  return new Intl.NumberFormat('vi-VN', {
    style: 'currency',
    currency: 'VND',
    maximumFractionDigits: 0,
  }).format(num);
}

/**
 * Format tiền hoàn: "Đã hoàn 50.000 đ"
 * Nếu null/0 -> "-" (em dash)
 * value có thể là chuỗi từ cột P ("=K4/2", "50000", "Hoàn Tiền", ...)
 */
export function formatRefund(value) {
  if (value == null || value === '') return '—';
  const num = typeof value === 'number'
    ? value
    : Number(String(value).replace(/[^\d-]/g, ''));
  if (Number.isNaN(num) || num === 0) return '—';
  const formatted = new Intl.NumberFormat('vi-VN', {
    maximumFractionDigits: 0,
  }).format(num);
  return `Đã hoàn ${formatted} đ`;
}

export function formatDate(value) {
  if (!value) return '—';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString('vi-VN');
}

/** Trả về em dash nếu rỗng */
export function orDash(value) {
  if (value == null || value === '' || value === 0) return '—';
  return value;
}