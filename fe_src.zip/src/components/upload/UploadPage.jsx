import { useEffect, useState } from 'react';
import Modal from '../common/Modal';
import DragDropZone from './DragDropZone';
import UploadResult from './UploadResult';
import { useDebounce } from '../../hooks/useDebounce';
import {
  uploadExcel,
  getProcessingNumber,
  updateProcessingNumber,
  managementSearch,
  deleteOrder,
  updateOrder,
} from '../../api/shopOrderApi';

const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:9879';

const SHEET_TYPES = [
  { value: 'NORMAL', label: 'Thường' },
  { value: 'VIP', label: 'Ưu tiên' },
  { value: 'SUPER_VIP', label: 'Ưu tiên VIP' },
];

function UploadIcon({ size = 22 }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
      <polyline points="17 8 12 3 7 8" />
      <line x1="12" y1="3" x2="12" y2="15" />
    </svg>
  );
}

export default function UploadPage() {
  const [showNumberModal, setShowNumberModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Config number
  const [currentNumber, setCurrentNumber] = useState('');
  const [savedNumber, setSavedNumber] = useState(null);
  const [savingNumber, setSavingNumber] = useState(false);

  // Upload
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState(null);
  const [uploadError, setUploadError] = useState('');

  // Table
  const [rows, setRows] = useState([]);
  const [loadingRows, setLoadingRows] = useState(false);
  const [keyword, setKeyword] = useState('');
  const debouncedKeyword = useDebounce(keyword, 600);
  const [sheetFilter, setSheetFilter] = useState('NORMAL');
  const [editRow, setEditRow] = useState(null);

  // Toast
  const [toast, setToast] = useState(null); // { type: 'success'|'error', msg: string }

  useEffect(() => {
    loadNumber();
  }, []);

  // Auto search khi debouncedKeyword hoặc sheetFilter thay đổi
  useEffect(() => {
    loadRows();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debouncedKeyword, sheetFilter]);

  // Toast auto-hide
  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2500);
    return () => clearTimeout(t);
  }, [toast]);

  function showToast(type, msg) {
    setToast({ type, msg });
  }

  async function loadNumber() {
    try {
      const val = await getProcessingNumber();
      if (val != null) {
        setCurrentNumber(String(val));
        setSavedNumber(val);
      }
    } catch (e) { }
  }

  async function loadRows() {
    setLoadingRows(true);
    try {
      const data = await managementSearch(debouncedKeyword, sheetFilter);
      setRows(Array.isArray(data) ? data : []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingRows(false);
    }
  }

  // Chỉ cho nhập số
  function handleNumberChange(e) {
    const v = e.target.value.replace(/[^0-9]/g, '');
    setCurrentNumber(v);
  }

  async function handleSaveNumber() {
    setSavingNumber(true);
    try {
      const v = currentNumber === '' ? null : Number(currentNumber);
      const updated = await updateProcessingNumber(v);
      setSavedNumber(updated);
      showToast('success', 'Đã lưu số đang xử lý');
    } catch (e) {
      showToast('error', 'Lỗi: ' + e.message);
    } finally {
      setSavingNumber(false);
    }
  }

  // Cập nhật nhanh: lấy số hiện tại + 1 và lưu
  async function handleQuickIncrement() {
    setSavingNumber(true);
    try {
      const base = Number(currentNumber || savedNumber || 0);
      const next = (Number.isFinite(base) ? base : 0) + 1;
      const updated = await updateProcessingNumber(next);
      setSavedNumber(updated);
      setCurrentNumber(String(updated ?? next));
      showToast('success', `Đã cập nhật lên ${updated ?? next}`);
    } catch (e) {
      showToast('error', 'Lỗi: ' + e.message);
    } finally {
      setSavingNumber(false);
    }
  }

  async function handleUpload() {
    if (!file) { setUploadError('Vui lòng chọn file'); return; }
    setUploadError('');
    setUploading(true);
    setResult(null);
    try {
      const r = await uploadExcel(file);
      setResult(r);
      setFile(null);
      loadRows();
    } catch (e) {
      setUploadError(e.message);
    } finally {
      setUploading(false);
    }
  }

  async function handleDelete(id) {
    if (!window.confirm('Xóa đơn id=' + id + '?')) return;
    try {
      await deleteOrder(id);
      loadRows();
    } catch (e) {
      alert(e.message);
    }
  }

  async function handleSaveEdit() {
    if (!editRow) return;
    try {
      await updateOrder(editRow.id, editRow);
      setEditRow(null);
      loadRows();
    } catch (e) {
      alert(e.message);
    }
  }

  function formatNumber(value) {
    if (value == null || value === '') return '—';

    const number = Number(value);
    if (!Number.isFinite(number)) return value;

    return `${Math.round(number).toLocaleString('vi-VN')} đ`;
  }

  return (
    <div className="min-h-screen w-full bg-gray-50">
      <div className="w-full px-4 sm:px-6 lg:px-8 py-6">
        <h1 className="text-2xl font-bold text-gray-800 mb-1">Quản lý đơn hàng</h1>
        <p className="text-sm text-gray-500 mb-6">
          Tìm kiếm, cập nhật, xóa dữ liệu đã upload
        </p>

        {/* Filter bar */}
        <div className="rounded-xl border bg-white p-4 mb-4 shadow-sm">
          <div className="flex flex-wrap gap-3 items-end">
            <div className="flex-1 min-w-[240px]">
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Tìm theo tài khoản
              </label>
              <input
                type="text"
                value={keyword}
                onChange={(e) => setKeyword(e.target.value)}
                placeholder="Nhập tài khoản... (để trống để xem tất cả)"
                className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Loại</label>
              <select
                value={sheetFilter}
                onChange={(e) => setSheetFilter(e.target.value)}
                className="rounded-lg border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none"
              >
                {SHEET_TYPES.map((s) => (
                  <option key={s.value} value={s.value}>{s.label}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Table */}
        <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="px-3 py-2 text-left">Số thứ tự</th>
                  <th className="px-3 py-2 text-left">Tài khoản</th>
                  <th className="px-3 py-2 text-left">Gói DV</th>
                  <th className="px-3 py-2 text-left">Giá</th>
                  <th className="px-3 py-2 text-left">Ngày đặt</th>
                  <th className="px-3 py-2 text-left">Ngày giao</th>
                  <th className="px-3 py-2 text-right">Hành động</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {loadingRows ? (
                  <tr><td colSpan="8" className="px-3 py-6 text-center text-gray-500">Đang tải...</td></tr>
                ) : rows.length === 0 ? (
                  <tr><td colSpan="8" className="px-3 py-6 text-center text-gray-500">Không có dữ liệu</td></tr>
                ) : rows.map((r) => (
                  <tr key={r.id} className="hover:bg-gray-50">
                    <td className="px-3 py-2">
                      <span className="ml-1 inline-flex items-center rounded-md bg-blue-100 px-2 py-0.5 text-xs font-semibold text-blue-700">
                        #{r.id}
                      </span>
                    </td>
                    <td className="px-3 py-2">{r.account}</td>
                    <td className="px-3 py-2">{r.servicePackage}</td>
                    <td className="px-3 py-2">{formatNumber(r.servicePrice)}</td>
                    <td className="px-3 py-2">{r.orderDate || '—'}</td>
                    <td className="px-3 py-2">{r.deliveryDate || '—'}</td>
                    <td className="px-3 py-2 text-right whitespace-nowrap">
                      <button
                        onClick={() => setEditRow({ ...r })}
                        className="rounded bg-amber-500 px-2 py-1 text-xs text-white hover:bg-amber-600 mr-1"
                      >Sửa</button>
                      <button
                        onClick={() => handleDelete(r.id)}
                        className="rounded bg-red-500 px-2 py-1 text-xs text-white hover:bg-red-600"
                      >Xóa</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Số đang xử lý -> nút tròn hiển thị số ở giữa */}
        <div className="fixed bottom-6 right-6 z-40">
          <button
            onClick={() => setShowNumberModal(true)}
            title="Số đang xử lý"
            className="flex h-14 w-14 items-center justify-center rounded-full bg-blue-600 text-white shadow-lg hover:bg-blue-700 font-bold text-lg"
          >
            {savedNumber ?? '—'}
          </button>
        </div>

        {/* Upload Excel -> icon */}
        <div className="fixed bottom-24 right-6 z-40">
          <button
            onClick={() => setShowUploadModal(true)}
            title="Upload Excel"
            className="flex h-14 w-14 items-center justify-center rounded-full bg-green-600 text-white shadow-lg hover:bg-green-700"
          >
            <UploadIcon size={22} />
          </button>
        </div>
      </div>

      {/* Toast */}
      {toast && (
        <div
          className={`fixed top-6 right-6 z-50 rounded-lg px-4 py-3 text-sm text-white shadow-lg transition ${toast.type === 'success' ? 'bg-green-600' : 'bg-red-600'
            }`}
        >
          {toast.msg}
        </div>
      )}

      {/* Modal số đang xử lý */}
      <Modal open={showNumberModal} onClose={() => setShowNumberModal(false)} title="Số đang xử lý hiện tại" maxWidth="max-w-md">
        <label className="block text-sm font-medium text-gray-700 mb-1">Số hiện tại</label>
        <input
          type="text"
          inputMode="numeric"
          pattern="[0-9]*"
          value={currentNumber}
          onChange={handleNumberChange}
          onWheel={(e) => e.currentTarget.blur()}
          onKeyDown={(e) => {
            if (['ArrowUp', 'ArrowDown', 'e', 'E', '+', '-', '.'].includes(e.key)) {
              e.preventDefault();
            }
          }}
          placeholder="VD: 125"
          className="w-full rounded-lg border border-gray-300 px-3 py-2 focus:border-blue-500 focus:outline-none
                     [appearance:textfield] [&::-webkit-outer-spin-button]:appearance-none [&::-webkit-inner-spin-button]:appearance-none"
        />
        <div className="mt-4 flex items-center gap-2">
          <button
            onClick={handleSaveNumber}
            disabled={savingNumber}
            className="rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700 disabled:opacity-60"
          >
            {savingNumber ? 'Đang lưu...' : 'Lưu'}
          </button>
          <button
            onClick={handleQuickIncrement}
            disabled={savingNumber}
            className="rounded-lg bg-emerald-600 px-4 py-2 text-white hover:bg-emerald-700 disabled:opacity-60"
          >
            + Cập nhật nhanh
          </button>
        </div>
      </Modal>

      {/* Modal upload */}
      <Modal open={showUploadModal} onClose={() => setShowUploadModal(false)} title="Upload file Excel">
        <div className="mb-3">
          <a
            href={`${BASE_URL}/api/shop-orders/template`}
            className="inline-flex items-center gap-1 text-sm text-blue-600 hover:underline"
            download
          >
            📥 Tải file mẫu (xlsx)
          </a>
        </div>
        <DragDropZone file={file} onFileSelected={setFile} />
        <button
          onClick={handleUpload}
          disabled={uploading}
          className="mt-4 w-full rounded-lg bg-green-600 px-4 py-2.5 font-medium text-white hover:bg-green-700 disabled:opacity-60"
        >
          {uploading ? 'Đang xử lý...' : 'Upload'}
        </button>
        {uploadError && (
          <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
            {uploadError}
          </div>
        )}
        <UploadResult result={result} />
      </Modal>

      {/* Modal edit */}
      <Modal open={!!editRow} onClose={() => setEditRow(null)} title={`Sửa đơn #${editRow?.id}`}>
        {editRow && (
          <div className="space-y-3 max-h-[70vh] overflow-y-auto pr-2">
            {[
              ['customerName', 'Tên khách'],
              ['orderPlace', 'Chỗ order'],
              ['servicePackage', 'Gói DV'],
              ['account', 'Tài khoản'],
              ['password', 'Mật khẩu'],
              ['priorityRegister', 'Đăng ký ưu tiên (Có/Không)'],
              ['priorityFee', 'Phí ưu tiên'],
              ['regionIp', 'IP vùng'],
              ['game20k', 'Game 20k'],
              ['servicePrice', 'Giá DV'],
              ['actualAmount', 'Thực nhận'],
              ['orderDate', 'Ngày đặt (yyyy-MM-dd)'],
              ['deliveryDate', 'Ngày giao (yyyy-MM-dd)'],
              ['holdDays', 'Số ngày treo'],
              ['regionTransferStatus', 'TT chuyển vùng'],
              ['depositRefund', 'Hoàn cọc'],
              ['refundNoteStatus', 'TT hoàn tiền (note)'],
              ['orderNoteStatus', 'TT đơn (note)'],
              ['noteRBown', 'Ghi chú R Bown'],
              ['noteLogAcc', 'Ghi chú log acc'],
              ['noteAddMoneyLogAcc', 'Ghi chú cộng tiền log acc'],
              ['noteAccError', 'Ghi chú acc lỗi'],
              ['noteAddMoneyFixAcc', 'Ghi chú cộng tiền fix lỗi acc'],
            ].map(([field, label]) => (
              <div key={field}>
                <label className="block text-xs font-medium text-gray-600 mb-1">{label}</label>
                <input
                  type="text"
                  value={editRow[field] ?? ''}
                  onChange={(e) => setEditRow({ ...editRow, [field]: e.target.value })}
                  className="w-full rounded border border-gray-300 px-2 py-1.5 text-sm focus:border-blue-500 focus:outline-none"
                />
              </div>
            ))}
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setEditRow(null)}
                className="rounded-lg border px-4 py-2 text-sm hover:bg-gray-50"
              >Hủy</button>
              <button
                onClick={handleSaveEdit}
                className="rounded-lg bg-blue-600 px-4 py-2 text-sm text-white hover:bg-blue-700"
              >Lưu</button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}