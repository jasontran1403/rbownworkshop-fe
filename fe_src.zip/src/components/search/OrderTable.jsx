import { formatVnd, formatRefund, formatDate } from '../../utils/format';
import { PackageBadge } from './StatusBadge';

export default function OrderTable({ orders, currentProcessingNumber }) {
  const current = Number(currentProcessingNumber);

  return (
    <div className="hidden md:block overflow-x-auto rounded-xl border border-gray-200 bg-white shadow-sm">
      <table className="min-w-full text-sm">
        <thead className="bg-gray-50 text-gray-600">
          <tr>
            <th className="px-4 py-3 text-left font-medium">Số thứ tự</th>
            <th className="px-4 py-3 text-left font-medium">Gói dịch vụ</th>
            <th className="px-4 py-3 text-left font-medium">Giá DV</th>
            <th className="px-4 py-3 text-left font-medium">Đăng ký ưu tiên</th>
            <th className="px-4 py-3 text-left font-medium">Phí ưu tiên</th>
            <th className="px-4 py-3 text-left font-medium">Ngày đăng ký</th>
            <th className="px-4 py-3 text-left font-medium">Ngày hoàn thành</th>
            <th className="px-4 py-3 text-left font-medium">Hoàn cọc</th>
            <th className="px-4 py-3 text-left font-medium">TT hoàn tiền</th>
            <th className="px-4 py-3 text-left font-medium">TT đơn</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {orders.map((o, i) => {
            const isDone = !!o.completeDate;
            const isProcessing = current && o.id === current;

            let rowBg = 'bg-gray-50';
            if (isDone) rowBg = 'bg-green-50';
            else if (isProcessing) rowBg = 'bg-blue-50';

            return (
              <tr
                key={i}
                className={`${rowBg} hover:brightness-95 transition-all
                  ${isProcessing ? 'ring-2 ring-blue-400 ring-inset animate-pulse-border' : ''}
                `}
              >
                <td className="px-4 py-3 font-medium">
                  <span className="ml-1 text-xs text-gray-400">#{o.id}</span>
                </td>
                <td className="px-4 py-3">
                  <PackageBadge sheetType={o.sheetType}>
                    {o.servicePackage || '—'}
                  </PackageBadge>
                </td>
                <td className="px-4 py-3 font-medium">{formatVnd(o.servicePrice)}</td>
                <td className="px-4 py-3">
                  {o.priorityRegister
                    ? <span className="text-green-700 font-medium">{o.priorityRegister}</span>
                    : <span className="text-gray-500">Không</span>}
                </td>
                <td className="px-4 py-3">{o.priorityFee ? formatVnd(o.priorityFee) : '—'}</td>
                <td className="px-4 py-3">{formatDate(o.registerDate)}</td>
                <td className="px-4 py-3">{formatDate(o.completeDate)}</td>
                <td className="px-4 py-3">{formatRefund(o.refundInfo)}</td>
                <td className="px-4 py-3">{o.refundNoteStatus || '—'}</td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2 py-0.5 text-xs font-medium ${
                    isDone ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                  }`}>
                    {o.orderNoteStatus || (isDone ? 'Hoàn thành' : 'Chưa hoàn thành')}
                  </span>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}