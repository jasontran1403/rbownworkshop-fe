import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import SearchInput from './SearchInput';
import OrderTable from './OrderTable';
import OrderCard from './OrderCard';
import { useDebounce } from '../../hooks/useDebounce';
import { searchOrders, getProcessingNumber } from '../../api/shopOrderApi';

const FILTER_OPTIONS = [
  { value: 'NORMAL', label: 'Thường' },
  { value: 'VIP', label: 'Ưu tiên' },
  { value: 'SUPER_VIP', label: 'Ưu tiên VIP' },
];

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const accountParam = searchParams.get('account') || '';
  const sheetTypeParam = searchParams.get('sheetType') || 'NORMAL';

  const [input, setInput] = useState(accountParam);
  const [sheetType, setSheetType] = useState(sheetTypeParam);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [currentNumber, setCurrentNumber] = useState(null);

  const debouncedInput = useDebounce(input, 600);

  useEffect(() => {
    (async () => {
      try { setCurrentNumber(await getProcessingNumber()); } catch (e) { }
    })();
  }, []);

  useEffect(() => {
    const params = {};
    if (debouncedInput) params.account = debouncedInput;
    params.sheetType = sheetType;
    setSearchParams(params, { replace: true });
  }, [debouncedInput, sheetType]); // eslint-disable-line

  useEffect(() => {
    if (!debouncedInput || debouncedInput.trim().length < 1) {
      setData(null); setError(''); return;
    }
    let cancel = false;
    (async () => {
      setLoading(true); setError('');
      try {
        const res = await searchOrders(debouncedInput.trim(), sheetType);
        if (!cancel) {
          setData(res);
          if (res?.currentProcessingNumber != null) setCurrentNumber(res.currentProcessingNumber);
        }
      } catch (e) {
        if (!cancel) { setError(e.message); setData(null); }
      } finally {
        if (!cancel) setLoading(false);
      }
    })();
    return () => { cancel = true; };
  }, [debouncedInput, sheetType]);

  useEffect(() => { setInput(accountParam); }, [accountParam]);
  useEffect(() => { setSheetType(sheetTypeParam); }, [sheetTypeParam]);

  const orders = data?.results || [];

  return (
    <div className="min-h-screen w-full bg-gray-50">
      <div className="w-full px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-between gap-3 mb-4">
          <h1 className="text-2xl font-bold text-gray-800">Tra cứu đơn hàng</h1>
          {currentNumber != null && (
            <span className="inline-flex items-center gap-1.5 rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-800 border border-blue-200">
              <span className="w-4 h-4 rounded-full bg-blue-500 animate-pulse" />
              Đang xử lý đến Đơn số {currentNumber}
            </span>
          )}
        </div>

        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <div className="flex-1">
            <SearchInput value={input} onChange={setInput} loading={loading} />
          </div>
          <select
            value={sheetType}
            onChange={(e) => setSheetType(e.target.value)}
            className="rounded-lg border border-gray-300 px-3 py-2 bg-white focus:border-blue-500 focus:outline-none"
          >
            {FILTER_OPTIONS.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </div>

        {error && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">{error}</div>
        )}

        {data && !error && (
          <div className="mt-6">
            <p className="text-sm text-gray-600 mb-3">
              Tìm thấy <b>{data.totalOrders}</b> đơn hàng
            </p>
            {orders.length === 0 ? (
              <div className="rounded-xl border bg-white p-8 text-center text-gray-500">
                Không tìm thấy đơn hàng nào
              </div>
            ) : (
              <>
                <OrderTable orders={orders} currentProcessingNumber={currentNumber} />
                <div className="space-y-3 md:hidden">
                  {orders.map((o, i) => (
                    <OrderCard key={i} order={o} currentProcessingNumber={currentNumber} />
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}